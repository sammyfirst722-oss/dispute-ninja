### The Medical Bill & Debt Dispute Action Kit: How to Audit, Dispute, and Eliminate Unfair Charges (Self-Advocacy Playbook)

---

#### Executive Summary

**The Medical Bill & Debt Dispute Action Kit** is a comprehensive guide designed to help medical consumers identify, dispute, and resolve charges they consider unfair. This playbook is tailored to help individuals understand their rights and responsibilities, empower them to manage their medical bills, and prevent uncollectible debts.

#### Legal Self-Advocacy Disclaimer

**Warning:** This guide is not legal advice. It is intended to serve as a practical guide to help individuals understand their rights and responsibilities as medical consumers. If you have concerns about your medical bills or debt collection practices, it is crucial to consult with a legal professional who can provide personalized advice based on your unique circumstances.

---

#### Step 1: The Medical Bill Audit Strategy

**Objective:** Identify and dispute charges you consider unfair.

**1. Gather Information:**
   - **Review Your Medical Bills:** Print and keep a copy of all your medical bills, including dates, amounts, and descriptions.
   - **Collect CPT Codes:** Obtain copies of all CPT codes used in your medical bills to verify the codes used.

**2. Check for Unbundling and Collateral Charges:**
   - **Unbundling:** Look for charges that appear to be separate charges rather than part of a larger transaction.
   - **Collateral Charges:** Identify any additional charges that are not included in the original bill.

**3. Verify CPT Codes:**
   - **Consult with a Healthcare Professional:** If you are unsure about the CPT codes, contact a healthcare professional to verify them.
   - **Use Electronic Health Records (EHRs):** If you have access to EHRs, review the medical records to confirm the charges.

**4. Apply for the Federal No Surprises Act:**
   - **Check for Coverage:** Ensure that the charges are covered under your insurance plan.
   - **Fill Out the Application:** If applicable, fill out the Federal No Surprises Act application to challenge unfair charges.

**5. Request Itemized Bills:**
   - **Contact Your Healthcare Provider:** Request an itemized bill from your healthcare provider.
   - **Review the Bill:** Compare the itemized bill with the original bill to identify any discrepancies.

**6. Gather Evidence:**
   - **Photographs and Documents:** Take photos and scan any relevant documents, such as receipts, hospital records, and medical records.
   - **Contact Your Healthcare Provider:** Ask your healthcare provider to provide additional supporting documentation if necessary.

**7. File a Complaint:**
   - **Contact Your Insurance Company:** File a complaint with your insurance company to dispute the charges.
   - **Contact Your Healthcare Provider:** File a complaint with your healthcare provider to dispute the charges.

**8. Stay Informed:**
   - **Follow Up:** Keep an eye on your healthcare bills and insurance statements to identify any new charges or disputes.
   - **Seek Advice from Professionals:** Consult with a legal professional or healthcare provider to stay informed and protected.

---

#### Step 2: The 30-Day Debt Collector Playbook

**Objective:** Stop harassing and prevent credit damage.

**1. Read FDCPA § 809:**
   - **Understand the Fair Debt Collection Practices Act:** Familiarize yourself with FDCPA § 809, which outlines the rights and responsibilities of debt collectors.

**2. Gather Evidence:**
   - **Photographs and Documents:** Take photos and scan any relevant documents, such as receipts, hospital records, and medical records.
   - **Contact Your Healthcare Provider:** Ask your healthcare provider to provide additional supporting documentation if necessary.

**3. File a Complaint:**
   - **Contact Your Federal Trade Commission (FTC):** File a complaint with the FTC to challenge unfair debt collection practices.
   - **Contact Your Debt Collector:** Contact your debt collector to request a cease and desist order to stop harassing practices.

**4. Stop Harassment:**
   - **Follow Up:** Keep an eye on your debt collector and contact them promptly if you receive harassing calls or emails.
   - **Seek Advice from Professionals:** Consult with a legal professional or debt collector agency to stop harassing practices.

**5. Prevent Credit Damage:**
   - **Report the Debt:** Report the debt to the Federal Trade Commission (FTC) if you believe the debt collector has violated FDCPA § 809.
   - **Seek Advice from Professionals:** Consult with a legal professional or debt collection agency to prevent credit damage.

**6. File a Complaint with Your Debt Collector:**
   - **Contact Your Debt Collector:** Contact your debt collector to request a cease and desist order to stop harassing practices.

**7. Maintain a Positive Credit Score:**
   - **Monitor Your Credit Report:** Check your credit report regularly to ensure that your credit score is maintained.
   - **Report False Debts:** Report any false debts to the Federal Trade Commission (FTC) to prevent them from being reported on your credit report.

---

#### Step 3: The Landlord Security Deposit Recovery Protocol

**Objective:** Recover your security deposit within statutory deadlines.

**1. Understand the Laws:**
   - **Research State Laws:** Familiarize yourself with the laws that govern security deposit recovery in your state.
   - **Review the Statutory Deadlines:** Identify the statutory deadlines for recovery of security deposits.

**2. Collect the Security Deposit:**
   - **Verify the Deposit:** Verify that the security deposit has been paid in full.
   - **Take a Photograph:** Take a photograph of the security deposit receipt to prove it has been paid in full.

**3. Gather Evidence:**
   - **Photographs and Documents:** Take photos and scan any relevant documents, such as receipts, hospital records, and medical records.
   - **Contact Your Healthcare Provider:** Ask your healthcare provider to provide additional supporting documentation if necessary.

**4. File a Complaint:**
   - **Contact Your State Attorney General:** File a complaint with your state attorney general to challenge unfair security deposit practices.
   - **Contact Your Landlord:** Contact your landlord to request a cease and desist order to stop harassing practices.

**5. Follow Up:**
   - **Monitor Your Security Deposit:** Keep an eye on your security deposit and contact your landlord promptly if you receive harassing calls or emails.
   - **Seek Advice from Professionals:** Consult with a legal professional or landlord agency to prevent harassing practices.

**6. File a Complaint with Your Landlord:****
   - **Contact Your Landlord:** Contact your landlord to request a cease and desist order to stop harassing practices.

**7. Maintain a Positive Credit Score:**
   - **Monitor Your Credit Report:** Check your credit report regularly to ensure that your credit score is maintained.
   - **Report False Debts:** Report any false debts to the Federal Trade Commission (FTC) to prevent them from being reported on your credit report.

---

#### Step 4: Step-by-Step Negotiation Phone Scripts

**Objective:** Get 40% to 70% settlement discounts on medical bills.

**1. Prepare Your Phone Script:**
   - **Gather the Necessary Documents:** Collect the necessary documents, such as your medical bills, insurance statements, and any supporting documentation.
   - **Write the Phone Script:** Write a detailed phone script that outlines your negotiation approach.

**2. Call Your Healthcare Provider:**
   - **Use the Script:** Use the phone script to engage in a detailed discussion with your healthcare provider about the charges.
   - **Request a Discount:** Ask your healthcare provider for a discount on the charges.
   - **Follow Up:** Follow up with your healthcare provider to ensure that the discount has been accepted.

**3. Call the Insurance Company:**
   - **Use the Script:** Use the phone script to engage in a detailed discussion with your insurance company about the charges.
   - **Request a Discount:** Ask your insurance company for a discount on the charges.
   - **Follow Up:** Follow up with your insurance company to ensure that the discount has been accepted.

**4. Call the Debt Collector:**
   - **Use the Script:** Use the phone script to engage in a detailed discussion with the debt collector about the charges.
   - **Request a Discount:** Ask the debt collector for a discount on the charges.
   - **Follow Up:** Follow up with the debt collector to ensure that the discount has been accepted.

**5. Call the Landlord:**
   - **Use the Script:** Use the phone script to engage in a detailed discussion with the landlord about the charges.
   - **Request a Discount:** Ask the landlord for a discount on the charges.
   - **Follow Up:** Follow up with the landlord to ensure that the discount has been accepted.

**6. Document Your Negotiations:**
   - **Keep a Record:** Keep a record of your negotiations, including the phone calls, emails, and any agreements reached.
   - **Seek Advice from Professionals:** Consult with a legal professional or negotiator to ensure that your negotiations are conducted legally and ethically.

---

#### Certified Mail & Paper Trail Instructions

**Objective:** Maintain a clear and complete record of your medical bills, insurance statements, and any supporting documentation.

**1. Keep a Copy of Your Medical Bills:**
   - **Print and Keep a Copy:** Print and keep a copy of all your medical bills, including dates, amounts, and descriptions.

**2. Gather CPT Codes:**
   - **Obtain Copies of All CPT Codes:** Obtain copies of all CPT codes used in your medical bills to verify the codes used.

**3. Verify CPT Codes:**
   - **Consult with a Healthcare Professional:** If you are unsure about the CPT codes, contact a healthcare professional to verify them.
   - **Use Electronic Health Records (EHRs):** If you have access to EHRs, review the medical records to confirm the charges.

**4. Apply for the Federal No Surprises Act:**
   - **Check for Coverage:** Ensure that the charges are covered under your insurance plan.
   - **Fill Out the Application:** If applicable, fill out the Federal No Surprises Act application to challenge unfair charges.

**5. Request Itemized Bills:**
   - **Contact Your Healthcare Provider:** Request an itemized bill from your healthcare provider.
   - **Review the Bill:** Compare the itemized bill with the original bill to identify any discrepancies.

**6. Gather Evidence:**
   - **Photographs and Documents:** Take photos and scan any relevant documents, such as receipts, hospital records, and medical records.
   - **Contact Your Healthcare Provider:** Ask your healthcare provider to provide additional supporting documentation if necessary.

**7. File a Complaint:**
   - **Contact Your Insurance Company:** File a complaint with your insurance company to dispute the charges.
   - **Contact Your Healthcare Provider:** File a complaint with your healthcare provider to dispute the charges.

**8. Stay Informed:**
   - **Follow Up:** Keep an eye on your healthcare bills and insurance statements to identify any new charges or disputes.
   - **Seek Advice from Professionals:** Consult with a legal professional or healthcare provider to stay informed and protected.

**9. File a Complaint with the FTC:**
   - **Contact Your State Attorney General:** File a complaint with your state attorney general to challenge unfair debt collection practices.
   - **Contact Your Landlord:** Contact your landlord to request a cease and desist order to stop harassing practices.

**10. Follow Up:**
   - **Monitor Your Security Deposit:** Keep an eye on your security deposit and contact your landlord promptly if you receive harassing calls or emails.
   - **Seek Advice from Professionals:** Consult with a legal professional or landlord agency to prevent harassing practices.

**11. File a Complaint with Your Landlord:****
   - **Contact Your Landlord:** Contact your landlord to request a cease and desist order to stop harassing practices.

**12. Maintain a Positive Credit Score:**
   - **Monitor Your Credit Report:** Check your credit report regularly to ensure that your credit score is maintained.
   - **Report False Debts:** Report any false debts to the Federal Trade Commission (FTC) to prevent them from being reported on your credit report.

---

---

**Note:** This guide is designed to be used as a self-advocacy tool and should not replace professional legal advice. If you have concerns about your medical bills or debt collection practices, it is crucial to consult with a legal professional who can provide personalized advice based on your unique circumstances.